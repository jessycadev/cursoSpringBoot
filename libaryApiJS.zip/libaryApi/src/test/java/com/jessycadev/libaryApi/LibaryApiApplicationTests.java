package com.jessycadev.libaryApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibaryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
